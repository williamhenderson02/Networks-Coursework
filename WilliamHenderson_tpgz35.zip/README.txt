# Networks-Coursework
How to use:
- First start server using python server.py [port]
- Connect to the server as a client using python server.py [username] [hostname] [port]
- To send a message to the chat room simply type a message and hit the enter key
- To upload a file use "upload/filename"
    - There are 3 example text files to upload
- To quit type "quit" and hit the enter key
